from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from app.config import MONGO_URI , JWT_SECRET
from app.routers import auth, users, quantum_random, keys
import os

app = FastAPI(title="Microservicio. FastApi. Mongo DB ATLAS. Oauth2|JWT. Qiskit. Generación de aleatoriedad cuántica.")

app.include_router(auth.router,prefix="/auth",tags=["Autenticación"])
app.include_router(users.router,prefix="/users",tags=["Usuarios"])
app.include_router(quantum_random.router,prefix="/random",tags=["Aleatoriedad cuántica(QRNG)"])
app.include_router(keys.router,prefix="/keys",tags=["Generador de claves seguras(Quantum-randomness)"])

static_dir = "landig_page"

if not os.path.exists(static_dir):
    os.makedirs(static_dir)
    
# Servir archivos estáticos (CSS, JS, imágenes, etc.)

app.mount("/assets", StaticFiles(directory=static_dir), name="assets")
app.mount("/images", StaticFiles(directory=os.path.join(static_dir, "images")), name="images")

                   
@app.get("/")
def serve_index():
    return FileResponse(os.path.join(static_dir, "index.html"))



    
    
          
